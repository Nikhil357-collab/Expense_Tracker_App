import streamlit as st

st.set_page_config(page_title="Expense Tracker", layout="wide")

st.title("💰 Smart Expense Tracker Dashboard")

st.markdown("""
Welcome to your personal finance dashboard.

Use the sidebar to navigate:
- Overview
- Category Analysis
- Trends
- Anomalies
""")
# pages/1_Overview----------------------------

import streamlit as st
import pandas as pd

df = pd.read_csv("data.csv")

st.title("📊 Overview")

total_spend = df["Amount"].sum()
avg_spend = df["Amount"].mean()

col1, col2 = st.columns(2)

col1.metric("Total Spending", f"₹{total_spend}")
col2.metric("Average Spending", f"₹{round(avg_spend,2)}")

st.subheader("Recent Transactions")
st.dataframe(df.tail(10))

#------------------------------
# pages/2_Category_Analysis.py

import streamlit as st
import pandas as pd

df = pd.read_csv("data.csv")

st.title("📂 Category Analysis")

category_spending = df.groupby("Category")["Amount"].sum()

st.bar_chart(category_spending)

st.subheader("Category Breakdown")
st.write(category_spending.sort_values(ascending=False))

#---------------------
# pages/3_Trends.py

import streamlit as st
import pandas as pd

df = pd.read_csv("data.csv")

df["Date"] = pd.to_datetime(df["Date"])
df["Month"] = df["Date"].dt.month

monthly = df.groupby("Month")["Amount"].sum()

st.title("📈 Trends & Forecast")

st.line_chart(monthly)

st.subheader("Monthly Spending")
st.write(monthly)

# pages/4_Anomalies.py

import streamlit as st
import pandas as pd

df = pd.read_csv("data.csv")

# Z-score
df["Z"] = (df["Amount"] - df["Amount"].mean()) / df["Amount"].std()
df["Anomaly"] = df["Z"].apply(lambda x: 1 if abs(x) > 2 else 0)

st.title("🚨 Anomaly Detection")

anomalies = df[df["Anomaly"] == 1]

st.write("Detected Anomalies")
st.dataframe(anomalies)

st.scatter_chart(df[["Amount"]])

st.sidebar.header("Filters")

category = st.sidebar.selectbox("Select Category", df["Category"].unique())

filtered_df = df[df["Category"] == category]

#-#####################-----data range filter
date_range = st.sidebar.date_input("Select Date Range", [])

if len(date_range) == 2:
    df = df[(df["Date"] >= str(date_range[0])) & (df["Date"] <= str(date_range[1]))]
    
    st.metric("Max Expense", df["Amount"].max())
st.metric("Min Expense", df["Amount"].min())

st.subheader("💡 Smart Insights")

top_category = df.groupby("Category")["Amount"].sum().idxmax()

st.success(f"Top spending category is {top_category}")

if top_category == "Food":
    st.warning("Try reducing food expenses 🍔")
    
    #--------------------------------#---------------
    import streamlit as st
import pandas as pd
from datetime import datetime

st.sidebar.header("➕ Add Expense")

date = st.sidebar.date_input("Date", datetime.today())
category = st.sidebar.selectbox("Category", ["Food", "Rent", "Travel", "Shopping", "Bills", "Entertainment"])
amount = st.sidebar.number_input("Amount", min_value=0)
payment = st.sidebar.selectbox("Payment Method", ["UPI", "Card", "Cash"])

if st.sidebar.button("Add Expense"):
    new_data = pd.DataFrame([[date, category, amount, payment]],
                            columns=["Date", "Category", "Amount", "Payment_Method"])
    
    df = pd.read_csv("data.csv")
    df = pd.concat([df, new_data], ignore_index=True)
    df.to_csv("data.csv", index=False)

    st.sidebar.success("Expense Added!")
    #----------------date filter
    start_date = st.date_input("Start Date")
end_date = st.date_input("End Date")

df["Date"] = pd.to_datetime(df["Date"])

df = df[(df["Date"] >= str(start_date)) & (df["Date"] <= str(end_date))]

#######----------------------######################
#LOGIN
username = st.text_input("Username")
password = st.text_input("Password", type="password")

if username == "admin" and password == "1234":
    st.success("Login Successful")
else:
    st.warning("Enter valid credentials")